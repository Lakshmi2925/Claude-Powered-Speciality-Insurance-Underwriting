# Claude Capstone Submission Package

Project: Claude-Powered Specialty Insurance Underwriting Workbench

Contents:
1. Source Code
   - React frontend
   - Node.js backend
   - Risk Engine
   - Capacity Engine
   - PDF upload and page-based chunking
   - Claude integration
2. Five-slide PowerPoint presentation
3. Supporting project documentation

Security note:
- No real Anthropic API key is included.
- Use server/.env.example to configure the application locally.

Capstone principle:
Capacity Engine calculates capacity.
Risk Engine calculates risk.
Claude interprets unstructured documents.
Authorized human underwriter makes the final decision.

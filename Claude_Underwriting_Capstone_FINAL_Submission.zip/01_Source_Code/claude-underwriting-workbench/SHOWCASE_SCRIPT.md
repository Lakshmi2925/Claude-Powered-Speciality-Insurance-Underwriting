# 3–4 Minute Showcase Script

## Opening

Hello. My capstone is the **Claude-Powered Specialty Insurance Underwriting Workbench**. The business problem I am addressing is repetitive underwriting review across structured case data and unstructured documents.

My core design principle is: **Rules calculate. Claude interprets. Humans decide.**

## Show case inputs

The customer provides the requested insurance limit. Available capacity is insurer-side information. I also capture previous claims, CAT exposure, and required-document status.

Exact checks such as `requested limit > available capacity`, missing mandatory documents, and the prototype risk score are handled by deterministic Node.js business rules, not by Claude.

## Show PDF upload

A document being present does not mean it has no risk. The underwriter can upload a Fire Inspection, Safety Certificate, or Financial Statement PDF.

For large PDFs, my backend uses page-based chunking. It creates valid smaller PDF chunks, Claude analyses each chunk, and then a consolidation step removes duplicates and produces one document-level risk summary.

This allows Claude to identify content-level issues, for example a non-operational sprinkler system, even when the Fire Inspection document itself is present.

## Run overall analysis

After document findings are available, I run the overall analysis. The risk score remains the deterministic business-rule result. Claude receives that result plus the case and document findings, then returns a concise summary, key concerns, document risks, and one of three advisory recommendations: PROCEED, REVIEW, or REFER.

I intentionally do not use APPROVE or REJECT because Claude is not the final underwriter.

## Human-in-the-loop

The authorized human underwriter reviews the original facts, deterministic rule results, and Claude insights before making the final decision.

## Close

The business value is reduced repetitive review, faster summarization, clearer surfacing of document concerns, and better decision support without giving final underwriting authority to AI.

**Rules calculate. Claude interprets. Humans decide.**

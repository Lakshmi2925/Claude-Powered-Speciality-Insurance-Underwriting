# SAFE UPGRADE — V4

This version includes BOTH:
1. chunked PDF upload/document analysis, and
2. a new insurer-side Capacity Engine.

## Safest approach

Do not overwrite the working V1/V3 folder immediately.

1. Keep your current working project as a backup.
2. Extract `claude-underwriting-workbench-v4-capacity-pdf-upload.zip` as a new folder.
3. In the new `server` folder run:

```cmd
npm install
npm run test:risk
npm run test:capacity
npm run test:pdf
npm start
```

4. In a second terminal:

```cmd
cd client
npm install
npm run dev
```

5. Keep `USE_MOCK_CLAUDE=true` for the first run.
6. Verify `/api/health` reports `capacityEngine: true` and `pdfChunking: true`.
7. Test **Calculate Available Capacity**.
8. Test a PDF upload.
9. Only after the whole UI works, switch to real Claude mode.

## Demo order

1. Show insurer capacity inputs.
2. Calculate Available Capacity.
3. Show Requested Limit vs Available Capacity.
4. Upload Fire Inspection PDF.
5. Explain page chunking.
6. Run overall underwriting analysis.
7. Show business rules separately from Claude insights.
8. Finish with: "Rules calculate. Claude interprets. Humans decide."

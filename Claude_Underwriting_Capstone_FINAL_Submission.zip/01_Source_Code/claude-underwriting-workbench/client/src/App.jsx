import { useState } from "react";

const initialForm = {
  companyName: "ABC Chemicals Ltd",
  industry: "Chemical Manufacturing",
  requestedLimit: 100,
  availableCapacity: 80,
  capacityInputs: {
    baseCapacity: 100,
    reinsuranceSupport: 50,
    existingExposure: 30,
    underwriterAuthority: 80,
    riskAppetiteLimit: 90
  },
  previousClaims: 3,
  catExposure: "HIGH",
  documents: {
    fireInspection: true,
    safetyCertificate: true,
    financialStatement: true
  },
  documentFindings: {
    fireInspection: "Sprinkler system is not operational and three fire extinguishers are expired.",
    safetyCertificate: "Two corrective actions are pending.",
    financialStatement: "High debt and reduced cash reserves."
  }
};

const documentLabels = {
  fireInspection: "Fire Inspection",
  safetyCertificate: "Safety Certificate",
  financialStatement: "Financial Statement"
};

function buildFindingText(analysis) {
  if (analysis.mock) return "";

  return [
    analysis.summary,
    analysis.riskFindings?.length
      ? `Risk findings: ${analysis.riskFindings.join("; ")}`
      : "",
    analysis.positiveFindings?.length
      ? `Positive controls: ${analysis.positiveFindings.join("; ")}`
      : "",
    analysis.missingInformation?.length
      ? `Missing / unclear information: ${analysis.missingInformation.join("; ")}`
      : "",
    `Document severity: ${analysis.severity}`
  ]
    .filter(Boolean)
    .join("\n");
}

function App() {
  const [form, setForm] = useState(initialForm);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [question, setQuestion] = useState("Why does this case require attention?");
  const [answer, setAnswer] = useState("");
  const [documentFiles, setDocumentFiles] = useState({});
  const [uploadingDocument, setUploadingDocument] = useState("");
  const [uploadMessages, setUploadMessages] = useState({});
  const [documentAnalyses, setDocumentAnalyses] = useState({});
  const [capacityLoading, setCapacityLoading] = useState(false);
  const [capacityMessage, setCapacityMessage] = useState(
    "Calculated from insurer-side capacity inputs."
  );

  const setField = (name, value) => setForm((prev) => ({ ...prev, [name]: value }));
  const setDocument = (name, value) =>
    setForm((prev) => ({
      ...prev,
      documents: { ...prev.documents, [name]: value }
    }));
  const setFinding = (name, value) =>
    setForm((prev) => ({
      ...prev,
      documentFindings: { ...prev.documentFindings, [name]: value }
    }));

  const setCapacityInput = (name, value) =>
    setForm((prev) => ({
      ...prev,
      capacityInputs: { ...prev.capacityInputs, [name]: value }
    }));

  async function calculateCapacity() {
    setCapacityLoading(true);
    setCapacityMessage("Calculating insurer-side available capacity...");

    try {
      const response = await fetch("/api/capacity/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          Object.fromEntries(
            Object.entries(form.capacityInputs).map(([key, value]) => [key, Number(value)])
          )
        )
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Capacity calculation failed");

      setForm((prev) => ({
        ...prev,
        availableCapacity: data.availableCapacity
      }));

      setCapacityMessage(
        `Available capacity: ₹${data.availableCapacity} Cr. Limiting factor: ${data.limitingFactors.join(
          ", "
        )}.`
      );
    } catch (e) {
      setCapacityMessage(e.message);
    } finally {
      setCapacityLoading(false);
    }
  }

  async function uploadAndAnalyseDocument(name) {
    const file = documentFiles[name];
    if (!file) {
      setUploadMessages((prev) => ({ ...prev, [name]: "Choose a PDF first." }));
      return;
    }

    setUploadingDocument(name);
    setUploadMessages((prev) => ({ ...prev, [name]: "Uploading, chunking and analysing PDF..." }));

    try {
      const body = new FormData();
      body.append("file", file);
      body.append("documentType", documentLabels[name]);

      const response = await fetch("/api/documents/analyze", {
        method: "POST",
        body
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Document analysis failed");

      const analysis = data.analysis;
      setDocument(name, true);
      setDocumentAnalyses((prev) => ({ ...prev, [name]: analysis }));

      if (!analysis.mock) {
        setFinding(name, buildFindingText(analysis));
      }

      const processText = `${analysis.processing.totalPages} page(s), ${analysis.processing.chunksAnalyzed} chunk(s)`;
      setUploadMessages((prev) => ({
        ...prev,
        [name]: analysis.mock
          ? `${data.fileName} uploaded and chunked (${processText}). Turn on real Claude mode to inspect PDF content.`
          : `${data.fileName} analysed successfully (${processText}).`
      }));
    } catch (e) {
      setUploadMessages((prev) => ({ ...prev, [name]: e.message }));
    } finally {
      setUploadingDocument("");
    }
  }

  async function analyze() {
    setLoading(true);
    setError("");
    setAnswer("");
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          requestedLimit: Number(form.requestedLimit),
          availableCapacity: Number(form.availableCapacity),
          capacityInputs: Object.fromEntries(
            Object.entries(form.capacityInputs).map(([key, value]) => [key, Number(value)])
          ),
          previousClaims: Number(form.previousClaims)
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Analysis failed");
      setResult(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function ask() {
    if (!result || !question.trim()) return;
    setAnswer("Loading...");
    const response = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ caseData: form, analysis: result, question })
    });
    const data = await response.json();
    setAnswer(response.ok ? data.answer : data.error);
  }

  const renderDocumentUpload = (name) => {
    const analysis = documentAnalyses[name];

    return (
      <div className="uploadCard" key={name}>
        <div className="uploadTop">
          <div>
            <strong>{documentLabels[name]}</strong>
            <small>PDF only. Large PDFs are automatically split by pages.</small>
          </div>
          {analysis && !analysis.mock && (
            <span className={`severity ${analysis.severity.toLowerCase()}`}>
              {analysis.severity}
            </span>
          )}
        </div>

        <input
          type="file"
          accept="application/pdf,.pdf"
          onChange={(e) =>
            setDocumentFiles((prev) => ({ ...prev, [name]: e.target.files?.[0] }))
          }
        />

        <button
          type="button"
          className="secondary"
          onClick={() => uploadAndAnalyseDocument(name)}
          disabled={uploadingDocument === name}
        >
          {uploadingDocument === name ? "Analysing PDF..." : "Upload & Analyse PDF"}
        </button>

        {uploadMessages[name] && (
          <small className="uploadMessage">{uploadMessages[name]}</small>
        )}

        {analysis && (
          <div className="processingInfo">
            <span>{analysis.processing.strategy}</span>
            <span>{analysis.processing.totalPages} pages</span>
            <span>{analysis.processing.chunksAnalyzed} chunks</span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="page">
      <header>
        <p className="eyebrow">AI Practitioner+ Capstone</p>
        <h1>Claude-Powered Specialty Insurance Underwriting Workbench</h1>
        <p className="subtitle">Rules calculate. Claude interprets. Humans decide.</p>
      </header>

      <main className="grid">
        <section className="card">
          <h2>Underwriting Case</h2>
          <div className="twoCol">
            <label>
              Company
              <input
                value={form.companyName}
                onChange={(e) => setField("companyName", e.target.value)}
              />
            </label>
            <label>
              Industry
              <input
                value={form.industry}
                onChange={(e) => setField("industry", e.target.value)}
              />
            </label>
            <label>
              Requested Limit (₹ Cr)
              <input
                type="number"
                value={form.requestedLimit}
                onChange={(e) => setField("requestedLimit", e.target.value)}
              />
            </label>
            <label>
              Calculated Available Capacity (₹ Cr)
              <input type="number" value={form.availableCapacity} readOnly />
            </label>
            <label>
              Previous Claims
              <input
                type="number"
                min="0"
                value={form.previousClaims}
                onChange={(e) => setField("previousClaims", e.target.value)}
              />
            </label>
            <label>
              CAT Exposure
              <select
                value={form.catExposure}
                onChange={(e) => setField("catExposure", e.target.value)}
              >
                <option>LOW</option>
                <option>MEDIUM</option>
                <option>HIGH</option>
              </select>
            </label>
          </div>

          <h3>Insurer Capacity Inputs</h3>
          <p className="muted miniNote">
            These are insurer-side inputs. Claude does not calculate or invent available capacity.
          </p>
          <div className="capacityGrid">
            <label>
              Base Insurer Capacity (₹ Cr)
              <input
                type="number"
                min="0"
                value={form.capacityInputs.baseCapacity}
                onChange={(e) => setCapacityInput("baseCapacity", e.target.value)}
              />
            </label>
            <label>
              Reinsurance Support (₹ Cr)
              <input
                type="number"
                min="0"
                value={form.capacityInputs.reinsuranceSupport}
                onChange={(e) => setCapacityInput("reinsuranceSupport", e.target.value)}
              />
            </label>
            <label>
              Existing Exposure (₹ Cr)
              <input
                type="number"
                min="0"
                value={form.capacityInputs.existingExposure}
                onChange={(e) => setCapacityInput("existingExposure", e.target.value)}
              />
            </label>
            <label>
              Underwriter Authority (₹ Cr)
              <input
                type="number"
                min="0"
                value={form.capacityInputs.underwriterAuthority}
                onChange={(e) => setCapacityInput("underwriterAuthority", e.target.value)}
              />
            </label>
            <label>
              Risk Appetite Limit (₹ Cr)
              <input
                type="number"
                min="0"
                value={form.capacityInputs.riskAppetiteLimit}
                onChange={(e) => setCapacityInput("riskAppetiteLimit", e.target.value)}
              />
            </label>
          </div>

          <button
            type="button"
            className="secondary capacityButton"
            onClick={calculateCapacity}
            disabled={capacityLoading}
          >
            {capacityLoading ? "Calculating..." : "Calculate Available Capacity"}
          </button>
          <small className="capacityMessage">{capacityMessage}</small>

          <h3>Mandatory Documents</h3>
          <p className="muted miniNote">
            Availability is a deterministic completeness check. PDF content analysis is separate.
          </p>
          <div className="checks">
            <label>
              <input
                type="checkbox"
                checked={form.documents.fireInspection}
                onChange={(e) => setDocument("fireInspection", e.target.checked)}
              />{" "}
              Fire Inspection
            </label>
            <label>
              <input
                type="checkbox"
                checked={form.documents.safetyCertificate}
                onChange={(e) => setDocument("safetyCertificate", e.target.checked)}
              />{" "}
              Safety Certificate
            </label>
            <label>
              <input
                type="checkbox"
                checked={form.documents.financialStatement}
                onChange={(e) => setDocument("financialStatement", e.target.checked)}
              />{" "}
              Financial Statement
            </label>
          </div>

          <h3>PDF Document Analysis</h3>
          <p className="muted uploadHint">
            Upload a PDF. The backend splits large PDFs into page chunks, Claude analyses each
            chunk, then consolidates the findings. Generated findings are copied into the editable
            notes below.
          </p>
          <div className="uploads">
            {Object.keys(documentLabels).map(renderDocumentUpload)}
          </div>

          <h3>Document Findings / Notes</h3>
          <p className="muted miniNote">
            These fields can be typed manually or populated from the PDF analysis.
          </p>
          <label>
            Fire Inspection
            <textarea
              value={form.documentFindings.fireInspection}
              onChange={(e) => setFinding("fireInspection", e.target.value)}
            />
          </label>
          <label>
            Safety Certificate
            <textarea
              value={form.documentFindings.safetyCertificate}
              onChange={(e) => setFinding("safetyCertificate", e.target.value)}
            />
          </label>
          <label>
            Financial Statement
            <textarea
              value={form.documentFindings.financialStatement}
              onChange={(e) => setFinding("financialStatement", e.target.value)}
            />
          </label>

          <button className="primary" onClick={analyze} disabled={loading}>
            {loading ? "Analysing..." : "Analyse Risk with Claude"}
          </button>
          {error && <p className="error">{error}</p>}
        </section>

        <section className="card results">
          <h2>Decision Support</h2>
          {!result ? (
            <p className="muted">
              Run an analysis to see business-rule findings and Claude insights.
            </p>
          ) : (
            <>
              <div className={`risk ${result.businessRules.riskLevel.toLowerCase()}`}>
                <span>Risk Level</span>
                <strong>{result.businessRules.riskLevel}</strong>
                <small>Score {result.businessRules.riskScore}</small>
              </div>

              {result.capacityCalculation && (
                <>
                  <h3>Capacity Engine</h3>
                  <div className="capacityResult">
                    <div><span>Supported Capacity</span><strong>₹{result.capacityCalculation.supportedCapacity} Cr</strong></div>
                    <div><span>Portfolio Headroom</span><strong>₹{result.capacityCalculation.portfolioHeadroom} Cr</strong></div>
                    <div><span>Authority Limit</span><strong>₹{result.capacityCalculation.underwriterAuthority} Cr</strong></div>
                    <div><span>Risk Appetite Limit</span><strong>₹{result.capacityCalculation.riskAppetiteLimit} Cr</strong></div>
                    <div className="capacityFinal">
                      <span>Available Capacity</span>
                      <strong>₹{result.capacityCalculation.availableCapacity} Cr</strong>
                    </div>
                  </div>
                  <p className="muted miniNote">
                    Limiting factor: {result.capacityCalculation.limitingFactors.join(", ")}
                  </p>
                </>
              )}

              <h3>Business Rule Findings</h3>
              <ul>
                {result.businessRules.findings.length ? (
                  result.businessRules.findings.map((x, i) => <li key={i}>{x}</li>)
                ) : (
                  <li>No rule-based concerns.</li>
                )}
              </ul>

              <h3>Claude Summary</h3>
              <p>{result.claudeAnalysis.summary}</p>

              <h3>Key Concerns</h3>
              <ul>
                {result.claudeAnalysis.keyConcerns.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>

              <h3>Document Content Risks</h3>
              <ul>
                {result.claudeAnalysis.documentRisks.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>

              <div className="recommendation">
                <span>AI Recommendation</span>
                <strong>{result.claudeAnalysis.recommendation}</strong>
                <p>{result.claudeAnalysis.recommendationReason}</p>
              </div>

              <p className="human">
                Final underwriting decision: <strong>Authorized Human Underwriter</strong>
              </p>

              <h3>Ask Claude</h3>
              <div className="askRow">
                <input value={question} onChange={(e) => setQuestion(e.target.value)} />
                <button onClick={ask}>Ask</button>
              </div>
              {answer && <div className="answer">{answer}</div>}
            </>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;

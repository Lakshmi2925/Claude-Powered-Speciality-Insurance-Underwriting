# Claude-Powered Specialty Insurance Underwriting Workbench — V4

Capstone project: a React + Node.js underwriting decision-support workbench that combines deterministic business rules with Claude for PDF document interpretation, case summarization, recommendation support, and Q&A. The final underwriting decision remains with an authorized human underwriter.

## Core principle

**Rules calculate. Claude interprets. Humans decide.**

## What is new in this version

- PDF upload for Fire Inspection, Safety Certificate, and Financial Statement.
- Large PDFs are split by **page ranges** instead of raw bytes.
- Each PDF chunk is analysed by Claude independently.
- Chunk findings are consolidated into one document-level summary.
- Consolidated findings are copied into the existing editable document-notes fields.
- The existing risk engine and `/api/analyze` flow remain separate and unchanged.

## Architecture

```text
Underwriter
   |
   v
React Frontend
   |
   +-------------------- PDF upload ---------------------+
   |                                                     |
   v                                                     v
Node.js API                                      Multer upload
   |                                                     |
   v                                                     v
Business Rules                                  pdf-lib page splitter
   |                                                     |
   |                                             12-page chunks (default)
   |                                                     |
   |                                             Claude per chunk
   |                                                     |
   |                                             Consolidated findings
   |                                                     |
   +------------------- case + document notes <----------+
   |
   v
Claude case analysis
   |
   v
Summary + concerns + PROCEED / REVIEW / REFER
   |
   v
Authorized Human Underwriter
```

## Prototype risk rules

These are transparent capstone-demo rules, **not universal insurance-industry standards**.

- Requested limit > available capacity: **+3**
- 3+ previous claims: **+2**
- One or more mandatory documents missing: **+2 total**
- High CAT exposure: **+2**
- Medium CAT exposure: **+1**
- Score 0-2: **LOW**
- Score 3-5: **MEDIUM**
- Score 6+: **HIGH**

Document-content findings from Claude do **not automatically change this deterministic score** in this capstone version.

## Why page chunking?

A large PDF can be expensive and harder to process as one request. This project splits a PDF into logical page ranges, sends each range to Claude, then consolidates the results. It does **not** split raw PDF bytes, because a raw byte slice is usually not a valid independent PDF document.

Default demo configuration:

- 12 pages per chunk
- 50 MB upload limit
- 240 pages maximum per uploaded document

You can adjust these values in `.env`.

## Run the server

```bash
cd server
npm install
copy .env.example .env
npm run test:risk
npm run test:pdf
npm start
```

On macOS/Linux, replace `copy` with:

```bash
cp .env.example .env
```

### Mock mode first

Keep:

```text
USE_MOCK_CLAUDE=true
```

This verifies the UI, upload pipeline, page chunking, business rules, and API flow without using an Anthropic API key. Mock mode does **not pretend to read PDF content**.

### Real Claude mode

Edit `server/.env`:

```text
ANTHROPIC_API_KEY=your_real_key
CLAUDE_MODEL=claude-sonnet-5
USE_MOCK_CLAUDE=false
PDF_PAGES_PER_CHUNK=12
MAX_PDF_MB=50
MAX_PDF_PAGES=240
```

Never expose the API key in React or commit it to source control.

## Run the client

Open a second terminal:

```bash
cd client
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## Recommended demo sequence

1. Explain Requested Limit vs insurer-side Available Capacity.
2. Explain that document availability and document content are different checks.
3. Upload a Fire Inspection PDF.
4. Show PDF page count and number of chunks.
5. Show Claude-generated document findings appearing in the editable notes.
6. Run `Analyse Risk with Claude`.
7. Explain the deterministic risk score separately from Claude insights.
8. Show `PROCEED / REVIEW / REFER` as decision support, not final approval/rejection.
9. Use `Ask Claude` for one case-specific question.
10. End with: **Rules calculate. Claude interprets. Humans decide.**

## Files to study before the showcase

- `ARCHITECTURE_AND_FLOW.md` — complete technical and business explanation.
- `SHOWCASE_SCRIPT.md` — short speaking script.
- `DEMO_QA.md` — evaluator-style questions and strong answers.
- `PRESENTATION_CONTENT.md` — content for the required five slides.


## V4: Insurer-side Capacity Engine

Available capacity is no longer a free-form value in the normal workflow.

The PoC calculates it with a transparent, configurable formula:

```text
Supported Capacity = Base Insurer Capacity + Reinsurance Support

Portfolio Headroom = max(
  Supported Capacity - Existing Exposure,
  0
)

Available Capacity = minimum of:
- Portfolio Headroom
- Underwriter Authority
- Risk Appetite Limit
```

Example:

```text
Base Capacity          = ₹100 Cr
Reinsurance Support    = ₹50 Cr
Existing Exposure      = ₹30 Cr
Portfolio Headroom     = ₹120 Cr
Underwriter Authority  = ₹80 Cr
Risk Appetite Limit    = ₹90 Cr

Available Capacity     = ₹80 Cr
```

This is a **capstone demonstration formula**, not a universal insurance-industry formula.
In production, the inputs and methodology would come from the insurer's underwriting,
exposure-management and reinsurance systems.

The backend owns this calculation. Claude does not invent or modify available capacity.

## PDF upload and chunked document analysis

The V4 build keeps the V3 PDF upload flow:

```text
React file input
→ multipart/form-data
→ Multer
→ pdf-lib page chunking
→ Claude analyses each valid PDF chunk
→ chunk findings are consolidated
→ editable document findings
→ overall underwriting analysis
```

Business rules check whether a mandatory document is present. Claude analyses the
unstructured content inside an uploaded document. These are deliberately separate jobs.

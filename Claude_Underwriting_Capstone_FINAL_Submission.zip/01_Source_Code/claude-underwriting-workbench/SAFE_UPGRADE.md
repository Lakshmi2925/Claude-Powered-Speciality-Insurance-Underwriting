# Safe Upgrade from the Working Version

Do not delete or overwrite your currently working project.

## Safest method

1. Keep your existing folder as-is.
2. Extract this updated ZIP beside it and rename the new folder if you want:

```text
claude-underwriting-workbench            <- current working backup
claude-underwriting-workbench-v3         <- updated chunked-PDF version
```

3. In the new `server` folder:

```cmd
npm install
copy .env.example .env
```

4. If you already have a real Anthropic API key in the old `.env`, copy only the value manually into the new `.env`. Never upload or share that key.

5. Test before enabling real Claude:

```cmd
npm run test:risk
npm run test:pdf
npm start
```

6. In a second terminal:

```cmd
cd client
npm install
npm run dev
```

7. Keep `USE_MOCK_CLAUDE=true` until `/api/health` and the upload/chunk UI are working.

8. Then set `USE_MOCK_CLAUDE=false`, restart the backend, and test one small PDF before trying a large one.

## Existing logic preserved

The deterministic `riskEngine.js` logic remains the same. File upload is an additive path through:

```text
/api/documents/analyze
```

The original case analysis remains:

```text
/api/analyze
```

This separation is intentional so a file-upload problem does not change the existing scoring logic.

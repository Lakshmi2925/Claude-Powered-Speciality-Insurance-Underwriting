import { analyzeRisk } from "./services/riskEngine.js";

const cases = [
  {
    name: "LOW",
    input: {
      requestedLimit: 40,
      availableCapacity: 70,
      previousClaims: 0,
      catExposure: "LOW",
      documents: { fireInspection: true, safetyCertificate: true, financialStatement: true }
    },
    expected: "LOW"
  },
  {
    name: "MEDIUM",
    input: {
      requestedLimit: 60,
      availableCapacity: 75,
      previousClaims: 4,
      catExposure: "MEDIUM",
      documents: { fireInspection: true, safetyCertificate: false, financialStatement: true }
    },
    expected: "MEDIUM"
  },
  {
    name: "HIGH",
    input: {
      requestedLimit: 100,
      availableCapacity: 80,
      previousClaims: 3,
      catExposure: "HIGH",
      documents: { fireInspection: false, safetyCertificate: true, financialStatement: true }
    },
    expected: "HIGH"
  }
];

let failures = 0;
for (const item of cases) {
  const result = analyzeRisk(item.input);
  const ok = result.riskLevel === item.expected;
  if (!ok) failures++;
  console.log(`${ok ? "PASS" : "FAIL"} ${item.name}: score=${result.riskScore}, level=${result.riskLevel}`);
}

if (failures) process.exit(1);

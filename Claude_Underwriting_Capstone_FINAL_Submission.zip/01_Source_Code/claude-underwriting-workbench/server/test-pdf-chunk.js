import { PDFDocument } from "pdf-lib";
import { splitPdfIntoChunks } from "./services/pdfChunkService.js";

async function createPdf(pageCount) {
  const pdf = await PDFDocument.create();
  for (let index = 0; index < pageCount; index += 1) {
    pdf.addPage([595, 842]);
  }
  return Buffer.from(await pdf.save());
}

const input = await createPdf(25);
const result = await splitPdfIntoChunks(input, { pagesPerChunk: 10, maxPages: 100 });

const actual = result.chunks.map((chunk) => [chunk.startPage, chunk.endPage, chunk.pageCount]);
const expected = [
  [1, 10, 10],
  [11, 20, 10],
  [21, 25, 5]
];

if (JSON.stringify(actual) !== JSON.stringify(expected)) {
  console.error("FAIL PDF chunking", { actual, expected });
  process.exit(1);
}

console.log("PASS PDF chunking", {
  totalPages: result.totalPages,
  chunks: actual
});

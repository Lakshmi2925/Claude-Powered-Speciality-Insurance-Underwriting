import Anthropic from "@anthropic-ai/sdk";

const underwritingSchema = {
  type: "object",
  properties: {
    summary: { type: "string" },
    keyConcerns: { type: "array", items: { type: "string" } },
    documentRisks: { type: "array", items: { type: "string" } },
    recommendation: {
      type: "string",
      enum: ["PROCEED", "REVIEW", "REFER"]
    },
    recommendationReason: { type: "string" }
  },
  required: [
    "summary",
    "keyConcerns",
    "documentRisks",
    "recommendation",
    "recommendationReason"
  ],
  additionalProperties: false
};

function getTextBlock(message) {
  const block = message.content.find((item) => item.type === "text");
  if (!block) throw new Error("Claude did not return a text response.");
  return block.text;
}

function mockClaude(caseData, ruleResult) {
  const documentRisks = [];
  const findings = caseData.documentFindings || {};

  for (const [name, value] of Object.entries(findings)) {
    if (value?.trim()) {
      documentRisks.push(`${name}: ${value.trim()}`);
    }
  }

  const recommendation =
    ruleResult.riskLevel === "HIGH"
      ? "REFER"
      : ruleResult.riskLevel === "MEDIUM"
      ? "REVIEW"
      : "PROCEED";

  return {
    summary: `${caseData.companyName} has a ${ruleResult.riskLevel.toLowerCase()} prototype risk classification based on deterministic business-rule checks. The listed rule findings and document observations should be reviewed by an authorized underwriter.`,
    keyConcerns: ruleResult.findings.length
      ? ruleResult.findings
      : ["No material rule-based concerns were identified by the prototype rules."],
    documentRisks: documentRisks.length
      ? documentRisks
      : ["No document-content findings were supplied for AI interpretation."],
    recommendation,
    recommendationReason: `Prototype decision support based on a ${ruleResult.riskLevel} rule-based classification. Final underwriting authority remains with the human underwriter.`
  };
}

function buildCasePrompt(caseData, ruleResult) {
  return `
UNDERWRITING CASE
Company: ${caseData.companyName}
Industry: ${caseData.industry}
Requested Limit: ₹${caseData.requestedLimit} Cr
Available Capacity: ₹${caseData.availableCapacity} Cr
Previous Claims: ${caseData.previousClaims}
CAT Exposure: ${caseData.catExposure}

DETERMINISTIC BUSINESS-RULE RESULTS
Risk Score: ${ruleResult.riskScore}
Risk Level: ${ruleResult.riskLevel}
Capacity Exceeded: ${ruleResult.capacityExceeded}
Capacity Gap: ₹${ruleResult.capacityGap} Cr
Missing Documents: ${ruleResult.missingDocuments.join(", ") || "None"}
Rule Findings:
${ruleResult.findings.map((x) => `- ${x}`).join("\n") || "- None"}

DOCUMENT FINDINGS / NOTES
Fire Inspection: ${caseData.documentFindings?.fireInspection || "No finding supplied"}
Safety Certificate: ${caseData.documentFindings?.safetyCertificate || "No finding supplied"}
Financial Statement: ${caseData.documentFindings?.financialStatement || "No finding supplied"}

Use only the supplied information. Do not invent claim causes, policy terms, pricing, or missing facts.
`;
}

export async function analyzeWithClaude(caseData, ruleResult) {
  if (process.env.USE_MOCK_CLAUDE === "true" || !process.env.ANTHROPIC_API_KEY) {
    return mockClaude(caseData, ruleResult);
  }

  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  const message = await client.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-5",
    max_tokens: 1200,
    system: `You are an AI assistant supporting specialty insurance underwriters.

Responsibilities:
- Summarize the supplied underwriting case.
- Explain important concerns already identified by deterministic rules.
- Analyse risk signals present in supplied document findings.
- Provide a decision-support recommendation.

Guardrails:
- Use only supplied information; do not invent facts.
- Do not modify, override, or recalculate the supplied risk score or risk level.
- Do not state that a policy is finally approved, rejected, bound, or declined.
- Recommendation must be PROCEED, REVIEW, or REFER.
- The final underwriting decision belongs to an authorized human underwriter.`,
    messages: [
      {
        role: "user",
        content: buildCasePrompt(caseData, ruleResult)
      }
    ],
    output_config: {
      format: {
        type: "json_schema",
        schema: underwritingSchema
      }
    }
  });

  return JSON.parse(getTextBlock(message));
}

export async function askClaude(caseData, analysis, question) {
  if (!question?.trim()) throw new Error("Question is required.");

  if (process.env.USE_MOCK_CLAUDE === "true" || !process.env.ANTHROPIC_API_KEY) {
    return `Based on the supplied case, focus on these points: ${(analysis?.businessRules?.findings || []).join("; ") || "no rule findings"}. The final underwriting decision must be made by an authorized human underwriter.`;
  }

  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const message = await client.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-5",
    max_tokens: 500,
    system: `You are an underwriting decision-support assistant. Answer only from the supplied case and analysis. Do not invent facts and do not make the final underwriting decision.`,
    messages: [
      {
        role: "user",
        content: `CASE:\n${JSON.stringify(caseData, null, 2)}\n\nANALYSIS:\n${JSON.stringify(analysis, null, 2)}\n\nQUESTION:\n${question}`
      }
    ]
  });

  return getTextBlock(message);
}

import Anthropic from "@anthropic-ai/sdk";
import { splitPdfIntoChunks } from "./pdfChunkService.js";

const chunkSchema = {
  type: "object",
  properties: {
    summary: { type: "string" },
    riskFindings: { type: "array", items: { type: "string" } },
    positiveFindings: { type: "array", items: { type: "string" } },
    missingInformation: { type: "array", items: { type: "string" } },
    severity: { type: "string", enum: ["LOW", "MEDIUM", "HIGH"] }
  },
  required: [
    "summary",
    "riskFindings",
    "positiveFindings",
    "missingInformation",
    "severity"
  ],
  additionalProperties: false
};

const consolidatedSchema = {
  type: "object",
  properties: {
    summary: { type: "string" },
    riskFindings: { type: "array", items: { type: "string" } },
    positiveFindings: { type: "array", items: { type: "string" } },
    missingInformation: { type: "array", items: { type: "string" } },
    severity: { type: "string", enum: ["LOW", "MEDIUM", "HIGH"] },
    needsHumanReview: { type: "boolean" }
  },
  required: [
    "summary",
    "riskFindings",
    "positiveFindings",
    "missingInformation",
    "severity",
    "needsHumanReview"
  ],
  additionalProperties: false
};

function getTextBlock(message) {
  const block = message.content.find((item) => item.type === "text");
  if (!block) throw new Error("Claude did not return a text response.");
  return block.text;
}

function createClient() {
  return new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
}

function isMockMode() {
  return process.env.USE_MOCK_CLAUDE === "true" || !process.env.ANTHROPIC_API_KEY;
}

async function analyseChunkWithClaude({ client, chunk, documentType, fileName }) {
  const message = await client.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-5",
    max_tokens: 1000,
    system: `You are an AI assistant supporting specialty insurance underwriters.

Analyse only the supplied PDF pages.
Extract factual findings that matter to underwriting.
Separate negative risk findings, positive controls, and missing/unclear information.
Do not invent facts.
Do not calculate or change the overall underwriting risk score.
Do not approve, reject, bind, or decline insurance.
The final decision belongs to an authorized human underwriter.`,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "document",
            source: {
              type: "base64",
              media_type: "application/pdf",
              data: chunk.buffer.toString("base64")
            }
          },
          {
            type: "text",
            text: `Document type: ${documentType}\nFile name: ${fileName}\nPages: ${chunk.startPage}-${chunk.endPage}\n\nAnalyse these pages only. Keep findings concise and grounded in the PDF.`
          }
        ]
      }
    ],
    output_config: {
      format: {
        type: "json_schema",
        schema: chunkSchema
      }
    }
  });

  return JSON.parse(getTextBlock(message));
}

async function consolidateWithClaude({ client, documentType, fileName, totalPages, chunkResults }) {
  const message = await client.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-5",
    max_tokens: 1200,
    system: `You consolidate chunk-level findings from one underwriting PDF.
Use only the supplied chunk findings.
Remove duplicates, preserve material factual distinctions, and prioritize risks.
Do not invent facts and do not make the final underwriting decision.`,
    messages: [
      {
        role: "user",
        content: `Document type: ${documentType}\nFile name: ${fileName}\nTotal pages: ${totalPages}\n\nChunk findings:\n${JSON.stringify(chunkResults, null, 2)}`
      }
    ],
    output_config: {
      format: {
        type: "json_schema",
        schema: consolidatedSchema
      }
    }
  });

  return JSON.parse(getTextBlock(message));
}

function buildMockResult({ fileName, documentType, totalPages, pagesPerChunk, chunks }) {
  return {
    summary: `${fileName} was uploaded and split successfully. Real PDF content analysis is disabled while USE_MOCK_CLAUDE=true.`,
    riskFindings: [],
    positiveFindings: [],
    missingInformation: [],
    severity: "LOW",
    needsHumanReview: false,
    mock: true,
    processing: {
      strategy: chunks.length > 1 ? "PAGE_CHUNKING" : "DIRECT_SINGLE_CHUNK",
      totalPages,
      pagesPerChunk,
      chunksAnalyzed: chunks.length,
      chunkRanges: chunks.map((chunk) => `${chunk.startPage}-${chunk.endPage}`)
    }
  };
}

export async function analyzePdfDocument({ buffer, fileName, documentType }) {
  const { totalPages, pagesPerChunk, chunks } = await splitPdfIntoChunks(buffer);

  if (isMockMode()) {
    return buildMockResult({ fileName, documentType, totalPages, pagesPerChunk, chunks });
  }

  const client = createClient();
  const chunkResults = [];

  // Sequential processing is intentional for a demo: simpler rate-limit behaviour
  // and easier observability than firing many PDF requests in parallel.
  for (const chunk of chunks) {
    const analysis = await analyseChunkWithClaude({
      client,
      chunk,
      documentType,
      fileName
    });

    chunkResults.push({
      chunkNumber: chunk.chunkNumber,
      pages: `${chunk.startPage}-${chunk.endPage}`,
      ...analysis
    });
  }

  const consolidated = await consolidateWithClaude({
    client,
    documentType,
    fileName,
    totalPages,
    chunkResults
  });

  return {
    ...consolidated,
    mock: false,
    processing: {
      strategy: chunks.length > 1 ? "PAGE_CHUNKING" : "DIRECT_SINGLE_CHUNK",
      totalPages,
      pagesPerChunk,
      chunksAnalyzed: chunks.length,
      chunkRanges: chunks.map((chunk) => `${chunk.startPage}-${chunk.endPage}`)
    }
  };
}

import { PDFDocument } from "pdf-lib";

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export async function splitPdfIntoChunks(buffer, options = {}) {
  const pagesPerChunk = positiveInteger(
    options.pagesPerChunk ?? process.env.PDF_PAGES_PER_CHUNK,
    12
  );
  const maxPages = positiveInteger(
    options.maxPages ?? process.env.MAX_PDF_PAGES,
    240
  );

  const sourcePdf = await PDFDocument.load(buffer, { ignoreEncryption: false });
  const pageCount = sourcePdf.getPageCount();

  if (pageCount === 0) {
    throw new Error("The uploaded PDF contains no pages.");
  }

  if (pageCount > maxPages) {
    throw new Error(
      `PDF has ${pageCount} pages. This capstone demo allows up to ${maxPages} pages per document.`
    );
  }

  const chunks = [];

  for (let start = 0; start < pageCount; start += pagesPerChunk) {
    const endExclusive = Math.min(start + pagesPerChunk, pageCount);
    const pageIndexes = Array.from(
      { length: endExclusive - start },
      (_, index) => start + index
    );

    const chunkPdf = await PDFDocument.create();
    const copiedPages = await chunkPdf.copyPages(sourcePdf, pageIndexes);
    copiedPages.forEach((page) => chunkPdf.addPage(page));
    const bytes = await chunkPdf.save();

    chunks.push({
      chunkNumber: chunks.length + 1,
      startPage: start + 1,
      endPage: endExclusive,
      pageCount: endExclusive - start,
      buffer: Buffer.from(bytes)
    });
  }

  return {
    totalPages: pageCount,
    pagesPerChunk,
    chunks
  };
}

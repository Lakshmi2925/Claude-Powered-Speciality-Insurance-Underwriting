function toNonNegativeNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) {
    throw new Error(`${fieldName} must be a non-negative number.`);
  }
  return number;
}

/**
 * Simplified, configurable capacity engine for this capstone PoC.
 *
 * Supported Capacity = Base Insurer Capacity + Reinsurance Support
 * Portfolio Headroom = max(Supported Capacity - Existing Exposure, 0)
 * Available Capacity = min(
 *   Portfolio Headroom,
 *   Underwriter Authority,
 *   Risk Appetite Limit
 * )
 *
 * In a production insurer, these inputs would come from internal
 * underwriting, exposure-management and reinsurance systems.
 */
export function calculateAvailableCapacity(input) {
  const baseCapacity = toNonNegativeNumber(input.baseCapacity, "Base capacity");
  const reinsuranceSupport = toNonNegativeNumber(
    input.reinsuranceSupport,
    "Reinsurance support"
  );
  const existingExposure = toNonNegativeNumber(
    input.existingExposure,
    "Existing exposure"
  );
  const underwriterAuthority = toNonNegativeNumber(
    input.underwriterAuthority,
    "Underwriter authority"
  );
  const riskAppetiteLimit = toNonNegativeNumber(
    input.riskAppetiteLimit,
    "Risk appetite limit"
  );

  const supportedCapacity = baseCapacity + reinsuranceSupport;
  const portfolioHeadroom = Math.max(supportedCapacity - existingExposure, 0);

  const constraints = [
    { name: "Portfolio Headroom", value: portfolioHeadroom },
    { name: "Underwriter Authority", value: underwriterAuthority },
    { name: "Risk Appetite Limit", value: riskAppetiteLimit }
  ];

  const availableCapacity = Math.min(...constraints.map((item) => item.value));
  const limitingFactors = constraints
    .filter((item) => item.value === availableCapacity)
    .map((item) => item.name);

  return {
    baseCapacity,
    reinsuranceSupport,
    existingExposure,
    supportedCapacity,
    portfolioHeadroom,
    underwriterAuthority,
    riskAppetiteLimit,
    availableCapacity,
    limitingFactors,
    formulaVersion: "CAPACITY-DEMO-v1"
  };
}

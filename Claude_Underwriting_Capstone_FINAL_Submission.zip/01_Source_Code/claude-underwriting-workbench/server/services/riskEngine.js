const REQUIRED_DOCUMENTS = {
  fireInspection: "Fire Inspection Report",
  safetyCertificate: "Safety Certificate",
  financialStatement: "Financial Statement"
};

export function analyzeRisk(caseData) {
  let riskScore = 0;
  const findings = [];
  const missingDocuments = [];

  const requestedLimit = Number(caseData.requestedLimit);
  const availableCapacity = Number(caseData.availableCapacity);
  const previousClaims = Number(caseData.previousClaims);
  const catExposure = String(caseData.catExposure || "LOW").toUpperCase();

  if ([requestedLimit, availableCapacity, previousClaims].some(Number.isNaN)) {
    throw new Error("Requested limit, available capacity, and previous claims must be valid numbers.");
  }

  // Rule 1: capacity
  const capacityExceeded = requestedLimit > availableCapacity;
  const capacityGap = capacityExceeded ? requestedLimit - availableCapacity : 0;

  if (capacityExceeded) {
    riskScore += 3;
    findings.push(`Requested limit exceeds available capacity by ₹${capacityGap} Cr`);
  }

  // Rule 2: claims — prototype rule, not an industry-standard threshold
  if (previousClaims >= 3) {
    riskScore += 2;
    findings.push(`${previousClaims} previous claims require review`);
  }

  // Rule 3: document completeness
  for (const [key, label] of Object.entries(REQUIRED_DOCUMENTS)) {
    if (!caseData.documents?.[key]) {
      missingDocuments.push(label);
    }
  }

  // Add +2 once if one or more mandatory documents are missing
  if (missingDocuments.length > 0) {
    riskScore += 2;
    findings.push(`Missing mandatory document(s): ${missingDocuments.join(", ")}`);
  }

  // Rule 4: catastrophe exposure
  if (catExposure === "HIGH") {
    riskScore += 2;
    findings.push("CAT exposure is high");
  } else if (catExposure === "MEDIUM") {
    riskScore += 1;
    findings.push("CAT exposure is medium");
  }

  // Final deterministic classification
  let riskLevel = "LOW";
  if (riskScore >= 6) riskLevel = "HIGH";
  else if (riskScore >= 3) riskLevel = "MEDIUM";

  return {
    riskScore,
    riskLevel,
    capacityExceeded,
    capacityGap,
    missingDocuments,
    findings,
    ruleVersion: "CAPSTONE-DEMO-v1"
  };
}

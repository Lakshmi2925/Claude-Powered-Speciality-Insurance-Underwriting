import { calculateAvailableCapacity } from "./services/capacityEngine.js";

const result = calculateAvailableCapacity({
  baseCapacity: 100,
  reinsuranceSupport: 50,
  existingExposure: 30,
  underwriterAuthority: 80,
  riskAppetiteLimit: 90
});

if (result.supportedCapacity !== 150) {
  throw new Error(`Expected supported capacity 150, got ${result.supportedCapacity}`);
}
if (result.portfolioHeadroom !== 120) {
  throw new Error(`Expected portfolio headroom 120, got ${result.portfolioHeadroom}`);
}
if (result.availableCapacity !== 80) {
  throw new Error(`Expected available capacity 80, got ${result.availableCapacity}`);
}
if (!result.limitingFactors.includes("Underwriter Authority")) {
  throw new Error(`Expected Underwriter Authority to be limiting factor.`);
}

console.log(
  `PASS CAPACITY: supported=${result.supportedCapacity}, headroom=${result.portfolioHeadroom}, available=${result.availableCapacity}, limiting=${result.limitingFactors.join(", ")}`
);

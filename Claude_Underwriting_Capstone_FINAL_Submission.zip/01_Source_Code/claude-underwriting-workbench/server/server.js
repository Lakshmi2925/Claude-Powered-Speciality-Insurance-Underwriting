import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import { analyzeRisk } from "./services/riskEngine.js";
import { calculateAvailableCapacity } from "./services/capacityEngine.js";
import { analyzeWithClaude, askClaude } from "./services/claudeService.js";
import { analyzePdfDocument } from "./services/documentAnalysisService.js";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const maxPdfMb = Number(process.env.MAX_PDF_MB || 50);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxPdfMb * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const looksLikePdf =
      file.mimetype === "application/pdf" || file.originalname.toLowerCase().endsWith(".pdf");

    if (!looksLikePdf) {
      return cb(new Error("Only PDF files are supported in this capstone demo."));
    }

    cb(null, true);
  }
});

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    mode: process.env.USE_MOCK_CLAUDE === "true" ? "mock" : "claude",
    pdfChunking: true,
    capacityEngine: true,
    pagesPerChunk: Number(process.env.PDF_PAGES_PER_CHUNK || 12)
  });
});


app.post("/api/capacity/calculate", (req, res) => {
  try {
    const calculation = calculateAvailableCapacity(req.body);
    return res.json(calculation);
  } catch (error) {
    return res.status(400).json({
      error: error.message || "Capacity calculation failed."
    });
  }
});

app.post("/api/documents/analyze", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "PDF file is required." });
    }

    const documentType = req.body.documentType || "Underwriting Document";
    const analysis = await analyzePdfDocument({
      buffer: req.file.buffer,
      fileName: req.file.originalname,
      documentType
    });

    return res.json({
      fileName: req.file.originalname,
      documentType,
      analysis
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message || "Document analysis failed." });
  }
});

app.post("/api/analyze", async (req, res) => {
  try {
    const caseData = req.body;

    if (!caseData.companyName || !caseData.industry) {
      return res.status(400).json({ error: "companyName and industry are required." });
    }

    // If insurer-side capacity inputs are present, the backend calculates
    // available capacity. This prevents Claude from inventing the number.
    let capacityCalculation = null;
    let enrichedCaseData = { ...caseData };

    if (caseData.capacityInputs) {
      capacityCalculation = calculateAvailableCapacity(caseData.capacityInputs);
      enrichedCaseData.availableCapacity = capacityCalculation.availableCapacity;
    }

    const businessRules = analyzeRisk(enrichedCaseData);
    const claudeAnalysis = await analyzeWithClaude(enrichedCaseData, businessRules);

    return res.json({
      companyName: enrichedCaseData.companyName,
      availableCapacity: enrichedCaseData.availableCapacity,
      capacityCalculation,
      businessRules,
      claudeAnalysis,
      humanDecisionRequired: true
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message || "Analysis failed." });
  }
});

app.post("/api/ask", async (req, res) => {
  try {
    const { caseData, analysis, question } = req.body;
    const answer = await askClaude(caseData, analysis, question);
    res.json({ answer });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || "Question failed." });
  }
});

app.use((error, _req, res, next) => {
  if (!error) return next();
  if (error instanceof multer.MulterError) {
    return res.status(400).json({ error: `Upload error: ${error.message}` });
  }
  if (error.message?.includes("Only PDF")) {
    return res.status(400).json({ error: error.message });
  }
  return next(error);
});

const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Underwriting API running on http://localhost:${port}`);
});

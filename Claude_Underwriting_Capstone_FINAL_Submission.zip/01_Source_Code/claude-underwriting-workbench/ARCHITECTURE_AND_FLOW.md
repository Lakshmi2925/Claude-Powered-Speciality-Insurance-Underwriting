# Complete Architecture and Flow — Study Notes

## 1. Business problem

Specialty insurance underwriters may need to review structured proposal data, claims information, capacity, CAT exposure, mandatory documents, and detailed findings inside those documents. Some checks are exact and deterministic; others require understanding unstructured language and document context.

The workbench separates those responsibilities instead of asking AI to do everything.

## 2. Inputs

The underwriter enters:

- Company name
- Industry
- Requested Limit — comes from the insured/company proposal
- Available Capacity — insurer-side information, not calculated by Claude
- Previous claims count
- CAT exposure
- Mandatory-document availability

The underwriter may also upload:

- Fire Inspection PDF
- Safety Certificate PDF
- Financial Statement PDF

## 3. Available Capacity

Requested Limit comes from the customer. Available Capacity comes from the insurer side. In a real organisation it can be sourced from internal underwriting/capacity systems and may reflect approved authority, risk appetite, existing exposure, and reinsurance arrangements. In this capstone it is a structured insurer-side input.

## 4. Business-rule engine

`server/services/riskEngine.js` performs exact checks:

- Capacity comparison
- Claims threshold
- Mandatory-document completeness
- CAT exposure rule
- Risk score and LOW/MEDIUM/HIGH classification

Claude is explicitly told not to recalculate or override these results.

## 5. Why PDF upload is separate from document completeness

A document can be present but still contain risk.

Example:

```text
Fire Inspection uploaded: YES
Business rule: document present

Inside PDF:
Sprinkler system not operational
Claude: material fire-protection concern
```

Therefore:

- Business rules answer: **Is the required document present?**
- Claude answers: **What does the document say, and what deserves attention?**

## 6. Large-PDF processing

`server/services/pdfChunkService.js` loads the uploaded PDF and creates valid smaller PDFs by copying page ranges.

Default:

```text
PDF 1-12 pages   -> Chunk 1
PDF 13-24 pages  -> Chunk 2
PDF 25-36 pages  -> Chunk 3
...
```

We split by pages, not by raw bytes.

## 7. Chunk-level Claude analysis

`server/services/documentAnalysisService.js` sends each valid PDF chunk to Claude.

For each chunk, Claude returns structured fields:

- summary
- riskFindings
- positiveFindings
- missingInformation
- severity: LOW / MEDIUM / HIGH

The prompt tells Claude:

- use only the supplied pages
- do not invent facts
- do not calculate the overall underwriting score
- do not approve or reject insurance

## 8. Consolidation

After all chunks are analysed, Claude receives only the structured chunk findings and consolidates them:

- removes duplicates
- preserves important differences
- prioritises material risks
- gives one document summary
- gives document severity
- indicates whether human review is needed

This is a simple Map/Reduce style design:

```text
MAP    = analyse each chunk
REDUCE = consolidate all chunk findings
```

## 9. How uploaded findings join the existing application

After document analysis, React copies the consolidated findings into the existing editable `Document Findings / Notes` field.

Then the normal case flow continues:

```text
Case data
+ Business-rule results
+ Document findings
        |
        v
Claude overall case analysis
```

This design preserves the original working `/api/analyze` flow.

## 10. Overall Claude case analysis

`server/services/claudeService.js` receives:

- original case data
- deterministic risk score and level
- rule findings
- document findings

Claude returns structured:

- summary
- keyConcerns
- documentRisks
- recommendation: PROCEED / REVIEW / REFER
- recommendationReason

## 11. Why not APPROVE / REJECT?

Claude is a decision-support assistant, not the final underwriting authority. `PROCEED / REVIEW / REFER` keeps the output advisory and supports a human-in-the-loop design.

## 12. Ask Claude

The `/api/ask` endpoint receives:

- the case
- the previous analysis
- an underwriter question

Claude is grounded to that context and instructed not to invent facts or make the final decision.

## 13. Responsible-AI controls

- Deterministic rules stay separate from generative reasoning.
- Claude is grounded in supplied data/documents.
- Structured JSON makes downstream handling predictable.
- AI cannot modify the score.
- AI recommendation vocabulary is restricted.
- Human underwriter remains final authority.
- Mock mode does not fake PDF-content analysis.

## 14. One-line architecture answer

> The React frontend collects case data and PDFs; Node.js runs deterministic risk rules, splits large PDFs into page chunks, Claude analyses and consolidates document findings, then Claude produces overall decision support while the authorized human underwriter keeps final authority.


## V4 capacity flow

```text
Customer Proposal
  └─ Requested Limit

Insurer-side Configuration
  ├─ Base Capacity
  ├─ Reinsurance Support
  ├─ Existing Exposure
  ├─ Underwriter Authority
  └─ Risk Appetite Limit
          ↓
     Capacity Engine
          ↓
    Available Capacity
          ↓
       Risk Engine
          ↓
 Risk Score / Risk Level
```

Available capacity is deterministic in this PoC. Claude does not calculate it.

## V4 document flow

```text
PDF Upload
  ↓
Multer
  ↓
pdf-lib splits by pages
  ↓
Claude analyses each chunk
  ↓
Structured chunk findings
  ↓
Consolidation
  ↓
Document risk summary
  ↓
Overall case analysis
```

# Showcase Q&A — Evaluator Questions and Strong Answers

## 1. What business problem are you solving?
Underwriters may spend repetitive effort checking structured proposal information and reading unstructured document findings. My workbench combines deterministic checks with Claude-supported document interpretation, summarization, and decision support.

## 2. Why did you choose Claude?
Deterministic JavaScript is better for exact calculations, while Claude adds value for language-heavy tasks such as interpreting PDF findings, summarizing multiple concerns, explaining their significance, and answering case-specific questions.

## 3. Why not send everything to Claude?
Exact business rules should be deterministic, testable, and explainable. Claude receives those facts but is not allowed to change them. This keeps the architecture predictable and auditable.

## 4. Who calculates Risk Score and Risk Level?
The Node.js business-rule engine. Claude does not calculate or override them.

## 5. Where does Requested Limit come from?
It comes from the insured/company proposal.

## 6. Where does Available Capacity come from?
It is insurer-side information. In a production system it could come from internal underwriting/capacity systems. In this capstone it is a structured insurer-side input.

## 7. What if all documents are available?
Availability only proves completeness. Claude can still find risks inside an available document. For example, a Fire Inspection may be present but state that the sprinkler system is not operational.

## 8. How do you handle large PDFs?
The backend uses `pdf-lib` to split the PDF into valid page-range chunks. Claude analyses each chunk, then a final consolidation combines the structured chunk findings and removes duplicates.

## 9. Why page chunking instead of byte chunking?
A random byte range is generally not a valid standalone PDF. Page-based splitting creates valid smaller PDFs and preserves page-level context.

## 10. What is Map/Reduce in your project?
Map means analysing each PDF chunk independently. Reduce means consolidating all chunk-level findings into one document-level result.

## 11. Does a document risk automatically change your risk score?
No. In this capstone the deterministic score uses only explicitly defined prototype rules. Claude document findings are separate AI insights. A production insurer could add approved deterministic rules later for specific document findings.

## 12. Why PROCEED / REVIEW / REFER instead of APPROVE / REJECT?
Claude is a decision-support assistant, not the final underwriting authority. Those categories keep the AI advisory and preserve human accountability.

## 13. Who makes the final decision?
An authorized human underwriter.

## 14. How do you reduce hallucination risk?
Claude is grounded in supplied case data or uploaded PDF pages, instructed not to invent facts, constrained to structured JSON for core analysis, prevented from changing deterministic calculations, and kept outside the final-decision role.

## 15. What happens in mock mode?
The application tests upload, page chunking, APIs, UI, and business rules, but it clearly states that it has not inspected PDF content. Real content analysis requires the Claude API.

## 16. What is the biggest business benefit?
Reduced repetitive review and summary preparation, with important structured and document-level concerns surfaced in one place for the underwriter.

## 17. Are your score thresholds industry standards?
No. They are transparent capstone demonstration rules. A production solution must use the insurer's approved underwriting guidelines, authority limits, governance, and validation.

## 18. What would you add in production?
Insurer-system integration for capacity and claims, authentication and role-based access, secure document storage, audit trails, insurer-approved scoring rules, monitoring, validation, data-governance controls, and production-scale retrieval/search for very large document sets.

## 19. Why not let Claude calculate Available Capacity?
Available Capacity is an insurer-side business fact, not something AI should invent. Claude can explain a capacity gap after the insurer's value is supplied.

## 20. Explain your project in one sentence.
The workbench combines deterministic underwriting rules with chunked Claude PDF analysis and human-in-the-loop decision support so underwriters can review cases faster without handing final authority to AI.


## Capacity Engine Questions

### Where does Available Capacity come from?
In this PoC it is calculated by an insurer-side Capacity Engine, not by Claude.
The engine calculates supported capacity from base capacity plus reinsurance support,
subtracts existing exposure to get portfolio headroom, and then takes the tightest
constraint among portfolio headroom, underwriter authority, and risk appetite limit.

### Is this an industry-standard capacity formula?
No. It is a simplified, configurable capstone formula designed to demonstrate the
architecture. A production implementation would integrate the insurer's actual
underwriting, portfolio exposure and reinsurance systems.

### Why not let Claude calculate capacity?
Capacity is an insurer-controlled deterministic value. It should be auditable and
repeatable. Claude is used for unstructured document interpretation and explanation,
not for inventing controlled financial limits.

# Five-Slide Executive Presentation Content

## Slide 1 — Context and Why Now

**Problem:** Specialty insurance underwriting can involve proposal data, claims, insurer capacity, CAT exposure, and lengthy risk documents. Important signals are spread across structured fields and unstructured PDFs.

**Impact:** Manual checking and document reading create repetitive effort and slow preparation of a consistent risk view.

**Why now:** Claude can interpret language-heavy PDF content while deterministic rules remain responsible for exact checks.

**Operating-model shift:** Manual review-first -> deterministic rules + AI-assisted document review -> human underwriting decision.

## Slide 2 — Current Challenges and Gaps

- Manual limit/capacity comparison.
- Manual claims and mandatory-document checks.
- Long Fire Inspection, Safety, and Financial PDFs require review.
- A document can be present but still contain material negative findings.
- Repetitive summarization across multiple inputs.
- Final decisions require accountable human underwriting judgment.

## Slide 3 — Vision and Future State

**Vision:** One underwriting workbench combining deterministic rules, chunked PDF analysis, Claude-generated insights, and human review.

**Future flow:** Proposal -> Business Rules -> PDF Chunking -> Claude Document Analysis -> Consolidation -> Overall Claude Analysis -> Human Decision.

**Expected value:** Faster review, lower repetitive effort, clearer document concerns, consistent summaries, and better decision support.

**Human-in-the-loop:** Claude supports the underwriter; it does not finally approve or reject insurance.

## Slide 4 — Solution Overview

**Frontend:** React case-entry, PDF upload, document-analysis status, and decision-support dashboard.

**Backend:** Node.js / Express orchestration.

**Business Rules:** Capacity, claims threshold, document completeness, CAT exposure, deterministic risk score.

**Large PDF Handling:** Multer receives uploads; `pdf-lib` splits PDFs by page ranges; Claude analyses each chunk; a consolidation step merges results.

**Claude:** PDF interpretation, case summary, key concerns, document risks, recommendation support, Ask-Claude Q&A.

**Core principle:** **Rules calculate. Claude interprets. Humans decide.**

## Slide 5 — Business Flow and Role of AI

1. Underwriter enters/loads proposal and insurer-side information.
2. Required PDFs can be uploaded.
3. Large PDFs are split into valid page chunks.
4. Claude analyses each chunk and returns structured findings.
5. Chunk findings are consolidated into one document-level result.
6. Deterministic business rules calculate risk score and level.
7. Claude receives the case + rule results + document findings.
8. Claude returns summary, concerns, and PROCEED / REVIEW / REFER decision support.
9. Authorized human underwriter makes the final decision.

**Responsible AI controls:** grounded data, no invented facts, structured outputs, deterministic score cannot be overridden, advisory recommendation vocabulary, human final authority.
